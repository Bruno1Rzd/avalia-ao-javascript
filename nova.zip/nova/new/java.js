
function inicio(){
    let nome= window.prompt('qual é o seu nome')
    window.alert(`olá, ${nome} é um prazer ter você aqui`)
} 

function somar(){
    let n1 = Number(window.prompt('digite um numero'))
    let n2 = Number(window.prompt('digite outro numero'))

    let res = document.querySelector('section#res')
    res.innerHTML =`<span> A soma entre ${n1} e ${n2} é igual a ${n1 + n2}</span>`

    }
    
    function multiplicar(){
        let n3 = Number(window.prompt('digite um numero'))
        let n4 = Number(window.prompt('digite outro numero'))
    
        let res = document.querySelector('section#res')
        res.innerHTML =`<span> A multiplicaçao entre ${n3} e ${n4} é igual a ${n3 * n4}</span>`
    
        }



    let contador = 0 
let res = document.querySelector('section#result')


function contar() {
    contador ++  
    res.innerHTML = `<p>O contador está com <mark>${contador}</mark> cliques.</p>`
}

function zerar() {
    contador = 0
    res.innerHTML = null
}
function media() {
    let nom = window.prompt('Qual é o nome do aluno?') 
    let n1 = Number(window.prompt(`Qual foi a primeira nota de ${nom}?`))
    let n2 = Number(window.prompt(`Além de ${n1}, qual foi a outra nota de ${nom}?`))
    med = (n1 + n2)/2 

    let res = document.getElementById('situacao')
    res.innerHTML = `<p>Calculando a média final de <mark>${nom}</mark>.</p>`
    res.innerHTML += `<p>As notas obtidas foram <mark>${n1} e ${n2}</mark>.</p>`
    res.innerHTML += `<p>A média final será <mark>${med}</mark>.</p>`}

    function impar() {
        let num = Number(window.prompt('Digite um número: '))
        let tipo
        if (num % 2 == 0) {
            tipo = '<strong>PAR</strong>'
        } else {
            tipo = '<strong>ÍMPAR</strong>'
        }
    
        let res = document.querySelector('section#resultado')
        res.innerHTML = `<p>O número ${num} que foi digitado é ${tipo}!</p>`
    }
    function maior() {
        let n1 = Number(window.prompt('Digite um número: '))
        let n2 = Number(window.prompt('Digite outro número: '))
        
        let res = document.querySelector('section#resu')
        if (n1 > n2) {
            res.innerHTML = `<p>Analisando os valores <mark>${n1}</mark> e <mark>${n2}</mark>, o maior valor é <strong>${n1}</strong></p>`
        } else if (n1 < n2) {
            res.innerHTML = `<p>Analisando os valores <mark>${n1}</mark> e <mark>${n2}</mark>, o maior valor é <strong>${n2}</strong></p>`
        } else {
            res.innerHTML = `<p>Analisando os valores <mark>${n1}</mark> e <mark>${n2}</mark>, ambos são <strong>IGUAIS</strong></p>`
        }
    }
    function info() {
        let agora = new Date
        let saida = document.getElementById('saida')
        saida.innerHTML = `<p>O que eu recebi do sistema foi <mark>${agora}</mark></p>`
    }

    function idade() {
        let agora = new Date
        let ano = agora.getFullYear()
    
        let nasc = Number(window.prompt('Em que ano você nasceu?'))
        let idade = ano - nasc
    
        let saida = document.getElementById('said')
        saida.innerHTML = `<p>Quem nasceu em ${nasc} vai completar <strong>${idade}</strong> anos em ${ano}.</p>`
    }


    function gerar() {
        let min = 100
        let max = 200
        let dif = max - min
        let aleatorio = Math.random()
        let num = min + Math.trunc(dif * aleatorio)
        
        let res = document.querySelector('section#resul')
        res.innerHTML += `<p>Acabei de pensar no número <mark>${num}</mark>!</p>`
    }
    
    function limpar() {
        let res = document.querySelector('section#resul')
        res.innerHTML = null 
    }



function sortear() {
    let min = 1
    let max = 10
    let dif = max - min
    let aleatorio = Math.random()
    computador = min + Math.trunc(dif * aleatorio)
}

function jogar() {

    let res = document.querySelector('section#ros')
    let computador = 0
    let jogador = 0
    jogador = Number(window.prompt('Qual é o seu palpite?'))
    if (jogador < computador) {
        res.innerHTML += `<p>Você falou ${jogador}. Meu número é <strong>MAIOR</strong>!</p>`
    } else if (jogador > computador) {
        res.innerHTML += `<p>Você falou ${jogador}. Meu número é <strong>MENOR</strong>!</p>`
    } else if (jogador == computador) {
        res.innerHTML += `<p><strong>PARABÉNS!</strong> Você acertou! Eu tinha sorteado o valor ${computador}!</p>`
        document.getElementById('botao').style.visibility = 'hidden'
    }
}

function calc() {
    let n1 = Number(prompt('Primeiro valor:'))
    let n2 = Number(prompt('Segundo valor:'))
    let op = Number(prompt(`Valores informados: ${n1} e ${n2}. \nO que vamos fazer? \n[1] Somar \n[2] Subtrair \n[3] Multiplicar \n[4] Dividir`))

    let saida = document.getElementById('fora')
    saida.innerHTML = `<h2>Calculando...</h2>`
    switch (op) {
        case 1:
            saida.innerHTML += `<p>${n1} + ${n2} = <strong>${n1+n2}</strong></p>`
            break
        case 2:
            saida.innerHTML += `<p>${n1} - ${n2} = <strong>${n1-n2}</strong></p>`
            break
        case 3:
            saida.innerHTML += `<p>${n1} x ${n2} = <strong>${n1*n2}</strong></p>`
            break
        case 4:
            saida.innerHTML += `<p>${n1} / ${n2} = <strong>${(n1/n2).toLocaleString('pt-BR')}</strong></p>`
            break
        default: 
            saida.innerHTML += `<p>OPÇÃO INVÁLIDA! Você digitou ${n1} e ${n2}, mas não sei o que fazer com eles. </p>`
            break
    }
}
function estação() { 
    let mês = prompt('Digite o mês em extenso (ex: Setembro)')
    let saída = document.querySelector('section#roi')
    let estação
    switch (mês.toUpperCase()) {
        case 'JANEIRO': case 'FEVEREIRO': case 'MARÇO':
            estação = 'INVERNO'
            break // Nunca se esqueça do break!!!
        case 'ABRIL': case 'MAIO': case 'JUNHO':
            estação = 'PRIMAVERA'
            break
        case 'JULHO': case 'AGOSTO': case 'SETEMBRO':
            estação = 'VERÃO'
            break
        case 'OUTUBRO': case 'NOVEMBRO': case 'DEZEMBRO':
            estação = 'OUTONO'
            break
        default:
            estação = 'INDEFINIDA'
            break
    }
    saída.innerHTML = `<p>No mês de <mark>${mês}</mark>, estamos na estação <mark><strong>${estação}</strong></mark>.</p>`
}

function contar() {
    let saida = document.getElementById('uid')

    saida.innerHTML += `<h2>Contando de 1 até 10</h2>`

    let cont = 1
    while (cont <= 15) {
        saida.innerHTML += ` ${cont} &#x1F449;`
        cont ++ 
    }
    saida.innerHTML += ` &#x1F3C1;`
}